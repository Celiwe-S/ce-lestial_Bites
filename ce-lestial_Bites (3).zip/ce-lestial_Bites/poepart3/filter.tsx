import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, ScrollView, TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
// as the chef edits the menu , the  customer will be able to see the menu/
// theyy can later click the button to checkout 
type MenuItem = string;


function CheckoutScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Checkout</Text>
      <Text>Your items will be processed here.</Text>
    </View>
  );
}


function MenuScreen({ navigation }: any) {
  const [starters, setStarters] = useState<MenuItem[]>([
    "Baked Camembert",
    "Mushroom Soup",
    "Baked Feta",
    "Crème Brûlée"
  ]);
  
  const [mainCourses, setMainCourses] = useState<MenuItem[]>([
    "Beef Enchiladas (beef strips with bacon and spinach)",
    "Stuffed Peppers (caramelized onions, mushrooms, and beef mince)",
    "Bacon Burger (chips/vegetables, cheese, pineapple, BBQ sauce)",
    "Lasagna (with ribs/vegetables)"
  ]);
  
  const [desserts, setDesserts] = useState<MenuItem[]>([
    "Malva Pudding (homemade jam with cream and custard)",
    "Waffles and Ice Cream (Bar One/Oreo/Kit Kat)",
    "Lemon Meringue Pie (with Ice Cream)",
    "Chocolate Mousse (with ice cream/custard)"
  ]);

  const [newItem, setNewItem] = useState<string>('');
  const [filter, setFilter] = useState<'all' | 'starters' | 'mainCourses' | 'desserts'>('all');

  const addItem = (item: string, setMenu: React.Dispatch<React.SetStateAction<MenuItem[]>>, menu: MenuItem[]) => {
    if (item.trim() !== '') {
      setMenu([...menu, item]);
      setNewItem('');
    }
  };

  
  const renderMenu = () => {
    switch (filter) {
      case 'starters':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Starters</Text>
            {starters.map((starter, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{starter}</Text>
              </View>
            ))}
          </View>
        );
      case 'mainCourses':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Main Courses</Text>
            {mainCourses.map((main, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{main}</Text>
              </View>
            ))}
          </View>
        );
      case 'desserts':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Desserts</Text>
            {desserts.map((dessert, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{dessert}</Text>
              </View>
            ))}
          </View>
        );
      default:
        return (
          <ScrollView style={styles.menuContainer}>
            <Text style={styles.courseTitle}>Starters</Text>
            {starters.map((starter, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{starter}</Text>
              </View>
            ))}
            <Text style={styles.courseTitle}>Main Courses</Text>
            {mainCourses.map((main, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{main}</Text>
              </View>
            ))}
            <Text style={styles.courseTitle}>Desserts</Text>
            {desserts.map((dessert, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{dessert}</Text>
              </View>
            ))}
          </ScrollView>
        );
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu</Text>

      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        <Button title="All" onPress={() => setFilter('all')} />
        <Button title="Starters" onPress={() => setFilter('starters')} />
        <Button title="Main Courses" onPress={() => setFilter('mainCourses')} />
        <Button title="Desserts" onPress={() => setFilter('desserts')} />
      </View>

   
      {renderMenu()}
      
      {/* Button to navigate to Checkout */}
      <View style={styles.nextPageButtonContainer}>
        <Button title="Go to Checkout" onPress={() => navigation.navigate('Checkout')} />
      </View>
    </View>
  );
}

// Stack Navigator
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Menu">
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="Checkout" component={CheckoutScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    paddingTop: 50,
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
  },
  menuContainer: {
    width: '90%',
  },
  courseContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
  },
  courseTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#333',
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginVertical: 5,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 20,
  },
  nextPageButtonContainer: {
    marginTop: 20,
  },
});
