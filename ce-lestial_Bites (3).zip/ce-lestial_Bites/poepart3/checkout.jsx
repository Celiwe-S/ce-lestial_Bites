import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Alert } from 'react-native';
// customer selects menu items and checks out 
export default function App() {
  //  store the selected items
  const [selectedStarters, setSelectedStarters] = useState([]);
  const [selectedMainCourses, setSelectedMainCourses] = useState([]);
  const [selectedDesserts, setSelectedDesserts] = useState([]);

  const handleSelect = (category, item) => {
    if (category === 'starters') {
      setSelectedStarters(prev => [...prev, item]);
    } else if (category === 'main') {
      setSelectedMainCourses(prev => [...prev, item]);
    } else if (category === 'dessert') {
      setSelectedDesserts(prev => [...prev, item]);
    }
  };

  // Function to handle checkout
  const handleCheckout = () => {
    if (selectedStarters.length === 0 && selectedMainCourses.length === 0 && selectedDesserts.length === 0) {
      Alert.alert('No items selected', 'Please select at least one item to proceed with checkout.');
    } else {
      const orderSummary = `
        Starters: ${selectedStarters.join(', ')}
        Main Courses: ${selectedMainCourses.join(', ')}
        Desserts: ${selectedDesserts.join(', ')}
      `;
      Alert.alert('Order Summary', orderSummary, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Confirm', onPress: () => alert('Order Confirmed, Our Kitchen is Prepering You feast!') },
      ]);
    }
  };

  return (
    <View style={styles.container}>
      {/* Bold "Celestial Bites" Text */}
      <Text style={styles.headerText}>Celestial Bites</Text>

    <Text>Hungry? Lets get you some food!</Text>

      <ScrollView style={styles.menuContainer}>
        {/* Starters Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Starters</Text>
          <Text style={styles.courseDescription}>
            A selection of light and flavorful appetizers to begin your meal.
          </Text>
          <Text style={styles.coursePrice}>R35.00</Text>
          <Text>Baked Camembert</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('starters', 'Baked Camembert')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Mushroom Soup</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('starters', 'Mushroom Soup')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Baked Feta</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('starters', 'Baked Feta')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Crème Brûlée</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('starters', 'Crème Brûlée')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
        </View>

        {/* Main Course Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Main Course</Text>
          <Text style={styles.courseDescription}>
            Our finest main dishes to satisfy your hunger and cravings.
          </Text>
          <Text style={styles.coursePrice}>R105.99</Text>
          <Text>Beef Enchiladas</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('main', 'Beef Enchiladas')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Stuffed Peppers</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('main', 'Stuffed Peppers')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Bacon Burger</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('main', 'Bacon Burger')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Lasagna</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('main', 'Lasagna')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
        </View>

        {/* Dessert Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Dessert</Text>
          <Text style={styles.courseDescription}>
            Sweet and delightful desserts to end your meal on a high note.
          </Text>
          <Text style={styles.coursePrice}>R34.99 - R55.00</Text>
          <Text>Malva Pudding</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('dessert', 'Malva Pudding')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Waffles and Ice Cream</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('dessert', 'Waffles and Ice Cream')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Lemon Meringue Pie</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('dessert', 'Lemon Meringue Pie')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
          <Text>Chocolate Mousse</Text>
          <TouchableOpacity style={styles.button} onPress={() => handleSelect('dessert', 'Chocolate Mousse')}>
            <Text style={styles.buttonText}>Select</Text>
          </TouchableOpacity>
        </View>

        {/* Checkout Button */}
        <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
          <Text style={styles.buttonText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'pink',
  },
  headerText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginVertical: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  menuContainer: {
    marginBottom: 20,
  },
  courseContainer: {
    marginBottom: 30,
  },
  courseTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  courseDescription: {
    fontSize: 14,
    marginBottom: 10,
  },
  coursePrice: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  button: {
    backgroundColor: 'white',
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  buttonText: {
    color: '#333',
    fontSize: 16,
  },
  checkoutButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 20,
  },
});