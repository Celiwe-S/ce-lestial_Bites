import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Screen for Chef
function EditScreen() {
  return (
    <View style={styles.container}>
      <Text>Edit Screen - Chef</Text>
    </View>
  );
}

// Screen for Customer
function FilterScreen() {
  return (
    <View style={styles.container}>
      <Text>Filter Screen - Customer</Text>
    </View>
  );
}

// Login Screen Component
function LoginScreen({ navigation }) {
  // State to manage the entered passwords for Chef and Customer
  const [chefPassword, setChefPassword] = useState('');
  const [customerPassword, setCustomerPassword] = useState('');

  // chef log in
  const handleChefLogin = () => {
    if (chefPassword === 'Chris101') {
      navigation.navigate('Edit'); // Navigate to the Edit screen if Chef is logged in 
    } else {
      alert('Incorrect Chef password.');
    }
  };
  // customer log in
  const handleCustomerLogin = () => {
    if (customerPassword === 'customer1') {
      navigation.navigate('Filter'); // Navigate to the Filter screen if Customer is logged in 
    } else {
      alert('Incorrect Customer password.');
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <Text style={styles.header}>Welcome To Celestial Bites</Text>

      <Text>Welcome Chef!</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Chef Password"
        secureTextEntry
        value={chefPassword}
        onChangeText={setChefPassword}
      />
      <Button 
        title="Login as Chef" 
        onPress={handleChefLogin} 
        color="#800080" 
      />

      <Text>Welcome Customer!</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Customer Password"
        secureTextEntry
        value={customerPassword}
        onChangeText={setCustomerPassword}
      />
      <Button 
        title="Login as Customer" 
        onPress={handleCustomerLogin} 
        color="#800080" 
      />
    </View>
  );
}

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Edit" component={EditScreen} />
        <Stack.Screen name="Filter" component={FilterScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'white',
    borderWidth: 1,
    marginBottom: 10,
    width: '100%',
    paddingLeft: 8,
  },
});
